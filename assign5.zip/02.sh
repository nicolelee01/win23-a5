#!/usr/bin/env bash

# (The absolute path to the program is provided as the first and only argument.)
# CALCULATOR=$1

echo "Here are some of my tests"

# Test 01: Ensure the program runs without error for addition.
if [[ $(../calculator 1 + 1) -ne 2 ]]; then  # 
  echo 'ERROR! Something is wrong with the addition!'
  exit 1
fi

# Test 02: Ensure the program runs without error for addition.
if [[ $(../calculator 2 / 3) -ne 0]]; then  # If the return code of $PROGRAM is non-zero (i.e. error)...
  echo 'ERROR! Something is wrong with the addition!'
  exit 1
fi